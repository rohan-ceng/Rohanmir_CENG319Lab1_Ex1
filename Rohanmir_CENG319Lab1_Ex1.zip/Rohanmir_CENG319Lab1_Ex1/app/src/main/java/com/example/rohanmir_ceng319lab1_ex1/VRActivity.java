package com.example.rohanmir_ceng319lab1_ex1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class VRActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_i);
        TextView name = (TextView)findViewById(R.id.name);
        TextView createcycle = (TextView)findViewById(R.id.createcycle);

        name.setText(getResources().getString(R.string.vName));
        createcycle.setText(getResources().getString(R.string.createMessage));
    }

    @Override
    protected void onStart() {
        super.onStart();
        TextView startcycle = (TextView)findViewById(R.id.startcycle);
        startcycle.setText(getResources().getString(R.string.startMessage));
    }
}
